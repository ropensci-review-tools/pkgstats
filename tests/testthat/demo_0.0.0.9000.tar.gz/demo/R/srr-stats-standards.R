#' NA_standards
#'
#' @srrstatsNA {RE3.3} is not applicable
#' @noRd
NULL

#' srrstats_standards
#'
#' @srrstatsVerbose TRUE
#' @srrstatsTODO Here is {RE4.4} as TODO, noting that text can
#' precede the standard number, as long as standards are
#' given within the first set of square brackets.
#' @noRd
NULL
