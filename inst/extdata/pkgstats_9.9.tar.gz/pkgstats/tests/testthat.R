library (testthat)
library (pkgstats)

test_check ("pkgstats")
