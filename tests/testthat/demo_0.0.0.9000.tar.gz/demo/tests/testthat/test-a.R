#' @srrstats {RE2.2} is addressed here
test_that("dummy test", {
    expect_true (TRUE)
})
