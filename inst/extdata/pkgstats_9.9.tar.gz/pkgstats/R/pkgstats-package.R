#' @keywords internal
#' @aliases pkgstats-package
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @useDynLib pkgstats, .registration = TRUE
## usethis namespace: end
NULL
