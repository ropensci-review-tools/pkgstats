library(testthat)
library(demo)

test_check("demo")
