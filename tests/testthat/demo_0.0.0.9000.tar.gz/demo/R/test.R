#' test_fn
#'
#' A test funtion
#'
#' @srrstats {G1.1, G1.2, G1.3} with some text
#' @srrstats Text can appear before standards {G2.0, G2.1}
#' @srrstatsTODO {RE1.1} standards which are still to be
#' addressed are tagged 'srrstatsTODO'
#'
#' @export
test_fn <- function() {
  message("This function does nothing")
}
